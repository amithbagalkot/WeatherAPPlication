export class Location{
    temperature;
    cityName;
    weather;
    constructor(temp,cityname,weather){
        this.temperature=temp;
        this.cityName=cityname;
        this.weather=weather;
    }
}